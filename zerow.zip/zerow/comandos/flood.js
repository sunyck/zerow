exports.run = (client, message, args)  => {

const id = "410978560543817748"

message.channel.send(`${message.channel.size}`)
}