exports.run = function (client, message, args) {

const id = "347598123821957121"

    message.author.send({embed:{
        description: "**Sistema de donate funciona da seguinte forma. \n\n1. Doando dinheiro voce voce se torna parceiro e permite o bot fica online e ter mais funçoes e voce tendo comando exclusivos criado so pra seu uso proprio ou do seu servidor \n2. como posso doar? apenas [clique aqui!!]() \n3. print de como funciona.**",
        color:"564654"
    }});
};
module.exports.help = {
    name: 'donate'
};