exports.run=function(c,a){a.channel.send("__**By:NoKIngg> digitem k!host todo dia para novas  informaçoes :V bj flwwwww'**__  `"+(b.createdTimestamp-a.createdTimestamp)+":v`")}

