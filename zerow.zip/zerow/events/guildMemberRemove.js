exports.run = (client, message, args) => {

client.on('guildMemberRemove', member => {

  if (member.guild.id != `${message.guild.id}`) return;

  client.guilds.get(`${message.guild.id}`).channels.get(`${message.channel.id}`).send({
      "embed": {
          "description": ":gem: **Usuario saiu do server:**\n\n\nNome: " + member,
          "color": 65535,
          "thumbnail": {
              "url": url
          }
      }
  });

});

}